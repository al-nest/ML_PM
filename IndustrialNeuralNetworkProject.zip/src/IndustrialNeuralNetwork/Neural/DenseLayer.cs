using IndustrialNeuralNetwork.Models;

namespace IndustrialNeuralNetwork.Neural;

public sealed class DenseLayer
{
    public int InputSize { get; set; }
    public int OutputSize { get; set; }
    public ActivationType Activation { get; set; }
    public double[][] Weights { get; set; } = [];
    public double[] Biases { get; set; } = [];
    public double DropoutRate { get; set; }

    private double[] _lastInput = [];
    private double[] _lastZ = [];
    private bool[] _dropoutMask = [];
    private double[][] _gradW = [];
    private double[] _gradB = [];
    private double[][] _mW = [];
    private double[][] _vW = [];
    private double[] _mB = [];
    private double[] _vB = [];

    public DenseLayer() { }

    public DenseLayer(int inputSize, int outputSize, ActivationType activation, Random random, string initialization, double dropoutRate)
    {
        InputSize = inputSize;
        OutputSize = outputSize;
        Activation = activation;
        DropoutRate = dropoutRate;
        Weights = CreateMatrix(outputSize, inputSize);
        Biases = new double[outputSize];
        var scale = initialization.Equals("he", StringComparison.OrdinalIgnoreCase)
            ? Math.Sqrt(2.0 / inputSize)
            : Math.Sqrt(2.0 / (inputSize + outputSize));
        for (var o = 0; o < outputSize; o++)
            for (var i = 0; i < inputSize; i++)
                Weights[o][i] = NextGaussian(random) * scale;
        AllocateOptimizerState();
    }

    public void AllocateOptimizerState()
    {
        _gradW = CreateMatrix(OutputSize, InputSize);
        _gradB = new double[OutputSize];
        _mW = CreateMatrix(OutputSize, InputSize);
        _vW = CreateMatrix(OutputSize, InputSize);
        _mB = new double[OutputSize];
        _vB = new double[OutputSize];
    }

    public void ZeroGradients()
    {
        for (var o = 0; o < OutputSize; o++)
        {
            Array.Clear(_gradW[o]);
            _gradB[o] = 0;
        }
    }

    public double[] Forward(double[] input, bool training, Random random, double leakyReluAlpha)
    {
        _lastInput = input;
        _lastZ = new double[OutputSize];
        var output = new double[OutputSize];
        _dropoutMask = new bool[OutputSize];
        for (var o = 0; o < OutputSize; o++)
        {
            var z = Biases[o];
            for (var i = 0; i < InputSize; i++) z += Weights[o][i] * input[i];
            _lastZ[o] = z;
            var a = ActivationFunctions.Activate(z, Activation, leakyReluAlpha);
            if (training && DropoutRate > 0 && Activation != ActivationType.Linear)
            {
                var keep = random.NextDouble() >= DropoutRate;
                _dropoutMask[o] = keep;
                a = keep ? a / (1.0 - DropoutRate) : 0.0;
            }
            else _dropoutMask[o] = true;
            output[o] = a;
        }
        return output;
    }

    public double[] Backward(double[] dOutput, double leakyReluAlpha)
    {
        var dInput = new double[InputSize];
        for (var o = 0; o < OutputSize; o++)
        {
            var d = dOutput[o];
            if (!_dropoutMask[o]) d = 0;
            else if (DropoutRate > 0 && Activation != ActivationType.Linear) d /= (1.0 - DropoutRate);
            d *= ActivationFunctions.Derivative(_lastZ[o], Activation, leakyReluAlpha);
            _gradB[o] += d;
            for (var i = 0; i < InputSize; i++)
            {
                _gradW[o][i] += d * _lastInput[i];
                dInput[i] += Weights[o][i] * d;
            }
        }
        return dInput;
    }

    public void ApplyGradients(double learningRate, int batchSize, double l2, OptimizerType optimizer, int step)
    {
        const double beta1 = 0.9;
        const double beta2 = 0.999;
        const double eps = 1e-8;
        var b1Corr = 1.0 - Math.Pow(beta1, step);
        var b2Corr = 1.0 - Math.Pow(beta2, step);
        for (var o = 0; o < OutputSize; o++)
        {
            var gb = _gradB[o] / batchSize;
            Biases[o] -= UpdateValue(ref _mB[o], ref _vB[o], gb, learningRate, optimizer, b1Corr, b2Corr, eps);
            for (var i = 0; i < InputSize; i++)
            {
                var gw = _gradW[o][i] / batchSize + l2 * Weights[o][i];
                Weights[o][i] -= UpdateValue(ref _mW[o][i], ref _vW[o][i], gw, learningRate, optimizer, b1Corr, b2Corr, eps);
            }
        }
    }

    private static double UpdateValue(ref double m, ref double v, double gradient, double lr, OptimizerType optimizer, double b1Corr, double b2Corr, double eps)
    {
        if (optimizer == OptimizerType.GradientDescent) return lr * gradient;
        m = 0.9 * m + 0.1 * gradient;
        v = 0.999 * v + 0.001 * gradient * gradient;
        return lr * (m / b1Corr) / (Math.Sqrt(v / b2Corr) + eps);
    }

    private static double[][] CreateMatrix(int rows, int cols)
    {
        var m = new double[rows][];
        for (var r = 0; r < rows; r++) m[r] = new double[cols];
        return m;
    }

    private static double NextGaussian(Random random)
    {
        var u1 = 1.0 - random.NextDouble();
        var u2 = 1.0 - random.NextDouble();
        return Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Cos(2.0 * Math.PI * u2);
    }
}
