using IndustrialNeuralNetwork.Models;

namespace IndustrialNeuralNetwork.Neural;

public sealed class NeuralNetwork
{
    public List<DenseLayer> Layers { get; set; } = [];
    public double LeakyReluAlpha { get; set; } = 0.01;

    public static NeuralNetwork Create(int inputSize, int outputSize, int[] hiddenLayers, ActivationType hiddenActivation, double dropoutRate, int seed, double leakyReluAlpha)
    {
        var random = new Random(seed);
        var network = new NeuralNetwork { LeakyReluAlpha = leakyReluAlpha };
        var previous = inputSize;
        foreach (var neurons in hiddenLayers)
        {
            if (neurons <= 0) throw new ArgumentException("Hidden layer size must be positive.", nameof(hiddenLayers));
            var init = hiddenActivation is ActivationType.ReLU or ActivationType.LeakyReLU ? "he" : "xavier";
            network.Layers.Add(new DenseLayer(previous, neurons, hiddenActivation, random, init, dropoutRate));
            previous = neurons;
        }
        network.Layers.Add(new DenseLayer(previous, outputSize, ActivationType.Linear, random, "xavier", 0));
        return network;
    }

    public void EnsureOptimizerState()
    {
        foreach (var layer in Layers) layer.AllocateOptimizerState();
    }

    public double[] Predict(double[] inputs)
    {
        var a = inputs;
        var random = new Random(0);
        foreach (var layer in Layers) a = layer.Forward(a, false, random, LeakyReluAlpha);
        return a;
    }

    public double[] Forward(double[] inputs, bool training, Random random)
    {
        var a = inputs;
        foreach (var layer in Layers) a = layer.Forward(a, training, random, LeakyReluAlpha);
        return a;
    }

    public void Backward(double[] predicted, double[] target)
    {
        var grad = new double[predicted.Length];
        for (var i = 0; i < grad.Length; i++) grad[i] = 2.0 * (predicted[i] - target[i]) / grad.Length;
        for (var layerIndex = Layers.Count - 1; layerIndex >= 0; layerIndex--)
            grad = Layers[layerIndex].Backward(grad, LeakyReluAlpha);
    }

    public void ZeroGradients()
    {
        foreach (var layer in Layers) layer.ZeroGradients();
    }

    public void ApplyGradients(double learningRate, int batchSize, double l2, OptimizerType optimizer, int step)
    {
        foreach (var layer in Layers) layer.ApplyGradients(learningRate, batchSize, l2, optimizer, step);
    }
}
