using IndustrialNeuralNetwork.Models;

namespace IndustrialNeuralNetwork.Neural;

internal static class ActivationFunctions
{
    public static double Activate(double x, ActivationType type, double alpha = 0.01) => type switch
    {
        ActivationType.ReLU => x > 0 ? x : 0,
        ActivationType.LeakyReLU => x > 0 ? x : alpha * x,
        ActivationType.Sigmoid => 1.0 / (1.0 + Math.Exp(-Math.Clamp(x, -60, 60))),
        ActivationType.Tanh => Math.Tanh(x),
        ActivationType.Linear => x,
        _ => x
    };

    public static double Derivative(double z, ActivationType type, double alpha = 0.01) => type switch
    {
        ActivationType.ReLU => z > 0 ? 1 : 0,
        ActivationType.LeakyReLU => z > 0 ? 1 : alpha,
        ActivationType.Sigmoid => SigmoidDerivative(z),
        ActivationType.Tanh => 1 - Math.Pow(Math.Tanh(z), 2),
        ActivationType.Linear => 1,
        _ => 1
    };

    private static double SigmoidDerivative(double z)
    {
        var s = Activate(z, ActivationType.Sigmoid);
        return s * (1 - s);
    }
}
