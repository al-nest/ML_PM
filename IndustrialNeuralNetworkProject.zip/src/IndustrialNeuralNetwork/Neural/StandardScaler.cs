namespace IndustrialNeuralNetwork.Neural;

public sealed class StandardScaler
{
    public double[] Means { get; set; } = [];
    public double[] StdDevs { get; set; } = [];

    public static StandardScaler Fit(IReadOnlyList<double[]> rows)
    {
        if (rows.Count == 0) throw new InvalidOperationException("Cannot fit scaler on empty data.");
        var n = rows[0].Length;
        var means = new double[n];
        var stds = new double[n];
        foreach (var row in rows)
            for (var i = 0; i < n; i++) means[i] += row[i];
        for (var i = 0; i < n; i++) means[i] /= rows.Count;
        foreach (var row in rows)
            for (var i = 0; i < n; i++) stds[i] += Math.Pow(row[i] - means[i], 2);
        for (var i = 0; i < n; i++)
        {
            stds[i] = Math.Sqrt(stds[i] / Math.Max(1, rows.Count - 1));
            if (stds[i] < 1e-12) stds[i] = 1.0;
        }
        return new StandardScaler { Means = means, StdDevs = stds };
    }

    public double[] Transform(double[] row)
    {
        var output = new double[row.Length];
        for (var i = 0; i < row.Length; i++) output[i] = (row[i] - Means[i]) / StdDevs[i];
        return output;
    }

    public double[] InverseTransform(double[] row)
    {
        var output = new double[row.Length];
        for (var i = 0; i < row.Length; i++) output[i] = row[i] * StdDevs[i] + Means[i];
        return output;
    }
}
