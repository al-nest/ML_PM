using System.Text.Json;
using System.Text.Json.Serialization;

namespace IndustrialNeuralNetwork.Models;

public static class ModelSerializer
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() }
    };

    public static void Save(ModelFile model, string path)
    {
        var json = JsonSerializer.Serialize(model, Options);
        File.WriteAllText(path, json);
    }

    public static ModelFile Load(string path)
    {
        var json = File.ReadAllText(path);
        var model = JsonSerializer.Deserialize<ModelFile>(json, Options)
            ?? throw new InvalidOperationException("Model file could not be deserialized.");
        model.Network.EnsureOptimizerState();
        return model;
    }
}
