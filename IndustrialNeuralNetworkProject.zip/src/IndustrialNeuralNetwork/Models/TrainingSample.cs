namespace IndustrialNeuralNetwork.Models;

public sealed record TrainingSample(DateTime TimeStamp, string DriveID, double[] Inputs, double[] Targets);
