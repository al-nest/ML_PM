namespace IndustrialNeuralNetwork.Models;

public sealed record OutputMetrics(
    string OutputName,
    double R2,
    double RMSE,
    double MAE,
    double MAPE,
    double AverageError,
    double MaxError);

public sealed record ModelMetrics(
    IReadOnlyList<OutputMetrics> PerOutput,
    OutputMetrics Average)
{
    public double AverageR2 => Average.R2;
}

public sealed record TrainingResult(
    string ModelPath,
    string DriveID,
    int EpochsCompleted,
    bool TargetReached,
    double BestValidationLoss,
    ModelMetrics Metrics,
    DateTime TrainedAtUtc);
