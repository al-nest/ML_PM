using IndustrialNeuralNetwork.Neural;

namespace IndustrialNeuralNetwork.Models;

public sealed class ModelFile
{
    public string Format { get; set; } = "IndustrialNeuralNetwork.Model.v1";
    public DateTime TrainedAtUtc { get; set; }
    public string DriveID { get; set; } = string.Empty;
    public int[] Architecture { get; set; } = [];
    public double LearningRate { get; set; }
    public double L2 { get; set; }
    public OptimizerType Optimizer { get; set; }
    public ActivationType HiddenActivation { get; set; }
    public double LeakyReluAlpha { get; set; }
    public StandardScaler InputScaler { get; set; } = new();
    public StandardScaler OutputScaler { get; set; } = new();
    public NeuralNetwork Network { get; set; } = new();
    public ModelMetrics? Metrics { get; set; }
}
