namespace IndustrialNeuralNetwork.Models;

public sealed record TrainingRequest
{
    public required string ConnectionString { get; init; }
    public required string DriveID { get; init; }
    public required double TargetR2 { get; init; }
    public required int MaxEpochs { get; init; }
    public required double LearningRate { get; init; }
    public required int BatchSize { get; init; }
    public required int[] HiddenLayers { get; init; }
    public required int Seed { get; init; }
    public string TableName { get; init; } = "dbo.TrainingData";
    public string ModelDirectory { get; init; } = ".";
    public double ValidationRatio { get; init; } = 0.2;
    public double L2 { get; init; } = 0.0001;
    public double LearningRateDecay { get; init; } = 0.0;
    public int EarlyStoppingPatience { get; init; } = 50;
    public double LeakyReluAlpha { get; init; } = 0.01;
    public double DropoutRate { get; init; } = 0.0;
    public OptimizerType Optimizer { get; init; } = OptimizerType.Adam;
    public ActivationType HiddenActivation { get; init; } = ActivationType.ReLU;
}

public enum OptimizerType { GradientDescent, Adam }
public enum ActivationType { ReLU, LeakyReLU, Sigmoid, Tanh, Linear }
