namespace IndustrialNeuralNetwork.Models;

public sealed record PumpInput(
    double In_Active_Vel_Fdbk,
    double In_AutoMan,
    double In_Commanded_SpdRef,
    double In_FaultAlarm,
    double In_FaultVFD,
    double In_Final_Speed_Ref,
    double In_Flow_Chiller1,
    double In_Flow_Chiller2,
    double In_Flow_Chiller3,
    double In_GlicolTemperature,
    double In_HeatEnergy_Chiller1,
    double In_HeatEnergy_Chiller2,
    double In_HeatEnergy_Chiller3,
    double In_ONState,
    double In_ProgSP,
    double In_Start)
{
    public double[] ToArray() =>
    [
        In_Active_Vel_Fdbk, In_AutoMan, In_Commanded_SpdRef, In_FaultAlarm, In_FaultVFD,
        In_Final_Speed_Ref, In_Flow_Chiller1, In_Flow_Chiller2, In_Flow_Chiller3,
        In_GlicolTemperature, In_HeatEnergy_Chiller1, In_HeatEnergy_Chiller2,
        In_HeatEnergy_Chiller3, In_ONState, In_ProgSP, In_Start
    ];
}
