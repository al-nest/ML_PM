namespace IndustrialNeuralNetwork.Models;

public sealed record PumpPrediction(
    double Out_DC_Bus_Volts,
    double Out_Drive_Temp_C,
    double Out_IGBT_Temp_C,
    double Out_Output_Current,
    double Out_Output_Power)
{
    public static PumpPrediction FromArray(double[] values)
    {
        if (values.Length != 5) throw new ArgumentException("Prediction vector must contain 5 values.", nameof(values));
        return new PumpPrediction(values[0], values[1], values[2], values[3], values[4]);
    }
}
