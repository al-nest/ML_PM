using IndustrialNeuralNetwork.Core;
using IndustrialNeuralNetwork.Models;

namespace IndustrialNeuralNetwork.Training;

public static class MetricsCalculator
{
    public static ModelMetrics Calculate(IReadOnlyList<double[]> actual, IReadOnlyList<double[]> predicted)
    {
        if (actual.Count != predicted.Count || actual.Count == 0) throw new ArgumentException("Actual and predicted collections must have equal, non-zero sizes.");
        var perOutput = new List<OutputMetrics>();
        for (var o = 0; o < ColumnSchema.OutputCount; o++)
        {
            var a = actual.Select(v => v[o]).ToArray();
            var p = predicted.Select(v => v[o]).ToArray();
            perOutput.Add(CalculateForOutput(ColumnSchema.OutputColumns[o], a, p));
        }
        var avg = new OutputMetrics(
            "Average",
            perOutput.Average(m => m.R2),
            perOutput.Average(m => m.RMSE),
            perOutput.Average(m => m.MAE),
            perOutput.Average(m => m.MAPE),
            perOutput.Average(m => m.AverageError),
            perOutput.Average(m => m.MaxError));
        return new ModelMetrics(perOutput, avg);
    }

    private static OutputMetrics CalculateForOutput(string name, double[] actual, double[] predicted)
    {
        var n = actual.Length;
        var mean = actual.Average();
        var ssTot = actual.Sum(x => Math.Pow(x - mean, 2));
        var ssRes = 0.0;
        var abs = new double[n];
        var signed = new double[n];
        var ape = new List<double>();
        for (var i = 0; i < n; i++)
        {
            var e = predicted[i] - actual[i];
            signed[i] = e;
            abs[i] = Math.Abs(e);
            ssRes += e * e;
            if (Math.Abs(actual[i]) > 1e-12) ape.Add(Math.Abs(e / actual[i]) * 100.0);
        }
        var r2 = ssTot <= 1e-12 ? 1.0 : 1.0 - ssRes / ssTot;
        return new OutputMetrics(name, r2, Math.Sqrt(ssRes / n), abs.Average(), ape.Count == 0 ? 0 : ape.Average(), signed.Average(), abs.Max());
    }
}
