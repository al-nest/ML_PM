using IndustrialNeuralNetwork.Core;
using IndustrialNeuralNetwork.Data;
using IndustrialNeuralNetwork.Models;
using IndustrialNeuralNetwork.Neural;

namespace IndustrialNeuralNetwork.Training;

public sealed class Trainer
{
    private readonly SqlTrainingDataProvider _dataProvider;

    public Trainer() : this(new SqlTrainingDataProvider()) { }

    public Trainer(SqlTrainingDataProvider dataProvider) => _dataProvider = dataProvider;

    public TrainingResult Train(string connectionString, string driveId, double targetR2, int maxEpochs, double learningRate, int batchSize, int[] hiddenLayers, int seed)
        => Train(new TrainingRequest
        {
            ConnectionString = connectionString,
            DriveID = driveId,
            TargetR2 = targetR2,
            MaxEpochs = maxEpochs,
            LearningRate = learningRate,
            BatchSize = batchSize,
            HiddenLayers = hiddenLayers,
            Seed = seed
        });

    public TrainingResult Train(TrainingRequest request)
    {
        Validate(request);
        Directory.CreateDirectory(request.ModelDirectory);
        var samples = _dataProvider.Load(request.ConnectionString, request.DriveID, request.TableName).ToList();
        if (samples.Count < 10) throw new InvalidOperationException("At least 10 TeachingIsActive records are required for training and validation.");

        var random = new Random(request.Seed);
        Shuffle(samples, random);
        var validationCount = Math.Max(1, (int)Math.Round(samples.Count * request.ValidationRatio));
        var validation = samples.Take(validationCount).ToList();
        var training = samples.Skip(validationCount).ToList();

        var inputScaler = StandardScaler.Fit(training.Select(s => s.Inputs).ToList());
        var outputScaler = StandardScaler.Fit(training.Select(s => s.Targets).ToList());
        var xTrain = training.Select(s => inputScaler.Transform(s.Inputs)).ToList();
        var yTrain = training.Select(s => outputScaler.Transform(s.Targets)).ToList();
        var xVal = validation.Select(s => inputScaler.Transform(s.Inputs)).ToList();
        var yValActual = validation.Select(s => s.Targets).ToList();

        var network = NeuralNetwork.Create(ColumnSchema.InputCount, ColumnSchema.OutputCount, request.HiddenLayers, request.HiddenActivation, request.DropoutRate, request.Seed, request.LeakyReluAlpha);
        NeuralNetwork bestNetwork = CloneNetwork(network);
        ModelMetrics bestMetrics = Evaluate(bestNetwork, inputScaler, outputScaler, validation);
        var bestLoss = ValidationLoss(bestNetwork, inputScaler, outputScaler, validation);
        var targetReached = bestMetrics.AverageR2 >= request.TargetR2;
        var epochsWithoutImprovement = 0;
        var completed = 0;
        var step = 0;

        for (var epoch = 1; epoch <= request.MaxEpochs; epoch++)
        {
            completed = epoch;
            var order = Enumerable.Range(0, xTrain.Count).ToArray();
            Shuffle(order, random);
            var lr = request.LearningRate / (1.0 + request.LearningRateDecay * (epoch - 1));
            for (var start = 0; start < order.Length; start += request.BatchSize)
            {
                var actualBatchSize = Math.Min(request.BatchSize, order.Length - start);
                network.ZeroGradients();
                for (var b = 0; b < actualBatchSize; b++)
                {
                    var idx = order[start + b];
                    var pred = network.Forward(xTrain[idx], true, random);
                    network.Backward(pred, yTrain[idx]);
                }
                step++;
                network.ApplyGradients(lr, actualBatchSize, request.L2, request.Optimizer, step);
            }

            var metrics = Evaluate(network, inputScaler, outputScaler, validation);
            var loss = ValidationLoss(network, inputScaler, outputScaler, validation);
            if (loss + 1e-12 < bestLoss)
            {
                bestLoss = loss;
                bestMetrics = metrics;
                bestNetwork = CloneNetwork(network);
                epochsWithoutImprovement = 0;
            }
            else epochsWithoutImprovement++;

            if (bestMetrics.AverageR2 >= request.TargetR2)
            {
                targetReached = true;
                break;
            }
            if (request.EarlyStoppingPatience > 0 && epochsWithoutImprovement >= request.EarlyStoppingPatience)
                break;
        }

        var model = new ModelFile
        {
            TrainedAtUtc = DateTime.UtcNow,
            DriveID = request.DriveID,
            Architecture = new[] { ColumnSchema.InputCount }.Concat(request.HiddenLayers).Concat(new[] { ColumnSchema.OutputCount }).ToArray(),
            LearningRate = request.LearningRate,
            L2 = request.L2,
            Optimizer = request.Optimizer,
            HiddenActivation = request.HiddenActivation,
            LeakyReluAlpha = request.LeakyReluAlpha,
            InputScaler = inputScaler,
            OutputScaler = outputScaler,
            Network = bestNetwork,
            Metrics = bestMetrics
        };
        var path = Path.Combine(request.ModelDirectory, $"Pump{request.DriveID}.model");
        ModelSerializer.Save(model, path);
        return new TrainingResult(path, request.DriveID, completed, targetReached, bestLoss, bestMetrics, model.TrainedAtUtc);
    }

    private static ModelMetrics Evaluate(NeuralNetwork network, StandardScaler inputScaler, StandardScaler outputScaler, IReadOnlyList<TrainingSample> samples)
    {
        var actual = new List<double[]>();
        var predicted = new List<double[]>();
        foreach (var sample in samples)
        {
            var p = network.Predict(inputScaler.Transform(sample.Inputs));
            predicted.Add(outputScaler.InverseTransform(p));
            actual.Add(sample.Targets);
        }
        return MetricsCalculator.Calculate(actual, predicted);
    }

    private static double ValidationLoss(NeuralNetwork network, StandardScaler inputScaler, StandardScaler outputScaler, IReadOnlyList<TrainingSample> samples)
    {
        var loss = 0.0;
        foreach (var sample in samples)
        {
            var p = outputScaler.Transform(outputScaler.InverseTransform(network.Predict(inputScaler.Transform(sample.Inputs))));
            var y = outputScaler.Transform(sample.Targets);
            for (var i = 0; i < p.Length; i++) loss += Math.Pow(p[i] - y[i], 2);
        }
        return loss / (samples.Count * ColumnSchema.OutputCount);
    }

    private static NeuralNetwork CloneNetwork(NeuralNetwork source)
    {
        var clone = new NeuralNetwork { LeakyReluAlpha = source.LeakyReluAlpha };
        foreach (var l in source.Layers)
        {
            var layer = new DenseLayer
            {
                InputSize = l.InputSize,
                OutputSize = l.OutputSize,
                Activation = l.Activation,
                DropoutRate = l.DropoutRate,
                Biases = l.Biases.ToArray(),
                Weights = l.Weights.Select(row => row.ToArray()).ToArray()
            };
            layer.AllocateOptimizerState();
            clone.Layers.Add(layer);
        }
        return clone;
    }

    private static void Validate(TrainingRequest request)
    {
        if (request.HiddenLayers.Length == 0) throw new ArgumentException("At least one hidden layer is required.");
        if (request.MaxEpochs <= 0) throw new ArgumentOutOfRangeException(nameof(request.MaxEpochs));
        if (request.LearningRate <= 0) throw new ArgumentOutOfRangeException(nameof(request.LearningRate));
        if (request.BatchSize <= 0) throw new ArgumentOutOfRangeException(nameof(request.BatchSize));
        if (request.ValidationRatio <= 0 || request.ValidationRatio >= 0.8) throw new ArgumentOutOfRangeException(nameof(request.ValidationRatio));
        if (request.DropoutRate < 0 || request.DropoutRate >= 1) throw new ArgumentOutOfRangeException(nameof(request.DropoutRate));
    }

    private static void Shuffle<T>(IList<T> values, Random random)
    {
        for (var i = values.Count - 1; i > 0; i--)
        {
            var j = random.Next(i + 1);
            (values[i], values[j]) = (values[j], values[i]);
        }
    }
}
