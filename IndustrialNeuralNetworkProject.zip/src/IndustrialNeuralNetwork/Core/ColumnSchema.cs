namespace IndustrialNeuralNetwork.Core;

public static class ColumnSchema
{
    public static readonly string[] InputColumns =
    [
        "In_Active_Vel_Fdbk", "In_AutoMan", "In_Commanded_SpdRef", "In_FaultAlarm",
        "In_FaultVFD", "In_Final_Speed_Ref", "In_Flow_Chiller1", "In_Flow_Chiller2",
        "In_Flow_Chiller3", "In_GlicolTemperature", "In_HeatEnergy_Chiller1",
        "In_HeatEnergy_Chiller2", "In_HeatEnergy_Chiller3", "In_ONState", "In_ProgSP", "In_Start"
    ];

    public static readonly string[] OutputColumns =
    [
        "Out_DC_Bus_Volts", "Out_Drive_Temp_C", "Out_IGBT_Temp_C", "Out_Output_Current", "Out_Output_Power"
    ];

    public const int InputCount = 16;
    public const int OutputCount = 5;
}
