using IndustrialNeuralNetwork.Core;
using IndustrialNeuralNetwork.Models;
using Microsoft.Data.SqlClient;
using System.Globalization;

namespace IndustrialNeuralNetwork.Data;

public sealed class SqlTrainingDataProvider
{
    public IReadOnlyList<TrainingSample> Load(string connectionString, string driveId, string tableName)
    {
        if (string.IsNullOrWhiteSpace(connectionString)) throw new ArgumentException("Connection string is required.", nameof(connectionString));
        if (string.IsNullOrWhiteSpace(driveId)) throw new ArgumentException("DriveID is required.", nameof(driveId));
        ValidateTableName(tableName);

        var columns = new List<string> { "TimeStamp", "DriveID" };
        columns.AddRange(ColumnSchema.InputColumns);
        columns.AddRange(ColumnSchema.OutputColumns);
        var sql = $"SELECT {string.Join(", ", columns.Select(c => "[" + c + "]"))} FROM {tableName} WHERE [DriveID] = @DriveID AND [TeachingIsActive] = 1 ORDER BY [TimeStamp]";

        var result = new List<TrainingSample>();
        using var connection = new SqlConnection(connectionString);
        connection.Open();
        using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@DriveID", driveId);
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            var timestamp = reader.GetDateTime(reader.GetOrdinal("TimeStamp"));
            var readDriveId = Convert.ToString(reader["DriveID"], CultureInfo.InvariantCulture) ?? driveId;
            var inputs = ReadVector(reader, ColumnSchema.InputColumns);
            var targets = ReadVector(reader, ColumnSchema.OutputColumns);
            if (inputs.All(double.IsFinite) && targets.All(double.IsFinite))
                result.Add(new TrainingSample(timestamp, readDriveId, inputs, targets));
        }
        return result;
    }

    private static double[] ReadVector(SqlDataReader reader, IReadOnlyList<string> columns)
    {
        var values = new double[columns.Count];
        for (var i = 0; i < columns.Count; i++)
        {
            var raw = reader[columns[i]];
            values[i] = raw == DBNull.Value ? double.NaN : Convert.ToDouble(raw, CultureInfo.InvariantCulture);
        }
        return values;
    }

    private static void ValidateTableName(string tableName)
    {
        if (string.IsNullOrWhiteSpace(tableName)) throw new ArgumentException("Table name is required.", nameof(tableName));
        foreach (var ch in tableName)
        {
            if (!(char.IsLetterOrDigit(ch) || ch == '_' || ch == '.' || ch == '[' || ch == ']'))
                throw new ArgumentException("Table name contains unsupported characters.", nameof(tableName));
        }
    }
}
