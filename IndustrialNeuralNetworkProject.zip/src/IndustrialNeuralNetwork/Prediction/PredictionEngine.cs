using IndustrialNeuralNetwork.Models;

namespace IndustrialNeuralNetwork.Prediction;

public sealed class PredictionEngine
{
    private readonly ModelFile _model;

    private PredictionEngine(ModelFile model) => _model = model;

    public static PredictionEngine Load(string modelPath)
    {
        if (!File.Exists(modelPath)) throw new FileNotFoundException("Model file not found.", modelPath);
        return new PredictionEngine(ModelSerializer.Load(modelPath));
    }

    public PumpPrediction Predict(PumpInput input)
    {
        var x = _model.InputScaler.Transform(input.ToArray());
        var yNormalized = _model.Network.Predict(x);
        var y = _model.OutputScaler.InverseTransform(yNormalized);
        return PumpPrediction.FromArray(y);
    }

    public double[] Predict(double[] inputs)
    {
        if (inputs.Length != 16) throw new ArgumentException("Input vector must contain 16 values.", nameof(inputs));
        var x = _model.InputScaler.Transform(inputs);
        return _model.OutputScaler.InverseTransform(_model.Network.Predict(x));
    }
}
