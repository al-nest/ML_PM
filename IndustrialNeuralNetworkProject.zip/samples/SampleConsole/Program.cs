using IndustrialNeuralNetwork.Models;
using IndustrialNeuralNetwork.Prediction;
using IndustrialNeuralNetwork.Training;

static int Fail(string message)
{
    Console.Error.WriteLine(message);
    return 1;
}

if (args.Length == 0) return Fail("Use: train or predict");

if (args[0].Equals("train", StringComparison.OrdinalIgnoreCase))
{
    var connectionString = Environment.GetEnvironmentVariable("INN_CONNECTION_STRING");
    if (string.IsNullOrWhiteSpace(connectionString)) return Fail("Set INN_CONNECTION_STRING.");

    var driveId = Environment.GetEnvironmentVariable("INN_DRIVE_ID");
    if (string.IsNullOrWhiteSpace(driveId)) return Fail("Set INN_DRIVE_ID.");

    var trainer = new Trainer();
    var result = trainer.Train(new TrainingRequest
    {
        ConnectionString = connectionString,
        DriveID = driveId,
        TargetR2 = double.TryParse(Environment.GetEnvironmentVariable("INN_TARGET_R2"), out var r2) ? r2 : 0.95,
        MaxEpochs = int.TryParse(Environment.GetEnvironmentVariable("INN_MAX_EPOCHS"), out var epochs) ? epochs : 1000,
        LearningRate = double.TryParse(Environment.GetEnvironmentVariable("INN_LEARNING_RATE"), out var lr) ? lr : 0.001,
        BatchSize = int.TryParse(Environment.GetEnvironmentVariable("INN_BATCH_SIZE"), out var bs) ? bs : 32,
        HiddenLayers = (Environment.GetEnvironmentVariable("INN_HIDDEN_LAYERS") ?? "64,32").Split(',', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray(),
        Seed = int.TryParse(Environment.GetEnvironmentVariable("INN_SEED"), out var seed) ? seed : 42,
        TableName = Environment.GetEnvironmentVariable("INN_TABLE") ?? "dbo.TrainingData",
        ModelDirectory = Environment.GetEnvironmentVariable("INN_MODEL_DIR") ?? "."
    });
    Console.WriteLine($"Model: {result.ModelPath}");
    Console.WriteLine($"Epochs: {result.EpochsCompleted}; Target reached: {result.TargetReached}; Average R2: {result.Metrics.AverageR2:F6}");
    return 0;
}

if (args[0].Equals("predict", StringComparison.OrdinalIgnoreCase))
{
    if (args.Length < 18) return Fail("Use: predict <modelPath> <16 numeric input values>");
    var engine = PredictionEngine.Load(args[1]);
    var values = args.Skip(2).Take(16).Select(double.Parse).ToArray();
    var p = engine.Predict(values);
    Console.WriteLine(string.Join(';', p.Select(v => v.ToString("G17"))));
    return 0;
}

return Fail("Unknown command.");
