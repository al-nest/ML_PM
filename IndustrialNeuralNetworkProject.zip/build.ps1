param(
    [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"
dotnet restore .\IndustrialNeuralNetwork.sln
dotnet build .\IndustrialNeuralNetwork.sln -c $Configuration --no-restore
