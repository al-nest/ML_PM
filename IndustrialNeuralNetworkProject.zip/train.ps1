param(
    [Parameter(Mandatory=$true)][string]$ConnectionString,
    [Parameter(Mandatory=$true)][string]$DriveID,
    [double]$TargetR2 = 0.95,
    [int]$MaxEpochs = 1000,
    [double]$LearningRate = 0.001,
    [int]$BatchSize = 32,
    [string]$HiddenLayers = "64,32",
    [int]$Seed = 42,
    [string]$TableName = "dbo.TrainingData",
    [string]$ModelDirectory = "."
)

$ErrorActionPreference = "Stop"
$env:INN_CONNECTION_STRING = $ConnectionString
$env:INN_DRIVE_ID = $DriveID
$env:INN_TARGET_R2 = "$TargetR2"
$env:INN_MAX_EPOCHS = "$MaxEpochs"
$env:INN_LEARNING_RATE = "$LearningRate"
$env:INN_BATCH_SIZE = "$BatchSize"
$env:INN_HIDDEN_LAYERS = $HiddenLayers
$env:INN_SEED = "$Seed"
$env:INN_TABLE = $TableName
$env:INN_MODEL_DIR = $ModelDirectory

dotnet run --project .\samples\SampleConsole\SampleConsole.csproj -c Release -- train
