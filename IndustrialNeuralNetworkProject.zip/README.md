# IndustrialNeuralNetwork

Biblioteka .NET 8 implementująca od zera sieć neuronową w C# do predykcji parametrów napędu z danych SQL Server.

## Budowanie

```powershell
dotnet restore .\IndustrialNeuralNetwork.sln
dotnet build .\IndustrialNeuralNetwork.sln -c Release
```

Wynikowa biblioteka DLL:

```text
src\IndustrialNeuralNetwork\bin\Release\net8.0\IndustrialNeuralNetwork.dll
```

## Dane SQL

Domyślna tabela: `dbo.TrainingData`. Można ją zmienić przez `TrainingRequest.TableName` albo zmienną `INN_TABLE` w skrypcie.

Biblioteka pobiera wyłącznie rekordy:

```sql
WHERE DriveID = @DriveID AND TeachingIsActive = 1
```

## Uczenie

Główne API:

```csharp
var result = new Trainer().Train(
    connectionString,
    driveId,
    targetR2,
    maxEpochs,
    learningRate,
    batchSize,
    hiddenLayers,
    seed);
```

Dostępny jest też `TrainingRequest` z opcjami dodatkowymi: Adam/GD, L2, dropout, decay, early stopping, tabela SQL i katalog modelu.

Model zapisuje się jako własny plik JSON `.model`, np. `Pump22115.model`, zawierający architekturę, normalizację, wagi, biasy, parametry uczenia, metryki, datę treningu i `DriveID`.

## Predykcja

```csharp
var engine = PredictionEngine.Load("Pump22115.model");
var prediction = engine.Predict(new PumpInput(...));
```

Zwracane wyjścia:

- `Out_DC_Bus_Volts`
- `Out_Drive_Temp_C`
- `Out_IGBT_Temp_C`
- `Out_Output_Current`
- `Out_Output_Power`

## Skrypty

- `build.ps1` buduje rozwiązanie.
- `train.ps1` uruchamia uczenie przez projekt konsolowy.
- `predict.ps1` wykonuje predykcję z pliku modelu.
