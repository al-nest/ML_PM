param(
    [Parameter(Mandatory=$true)][string]$ModelPath,
    [Parameter(Mandatory=$true)][double[]]$Inputs
)

$ErrorActionPreference = "Stop"
if ($Inputs.Count -ne 16) { throw "Exactly 16 input values are required." }
dotnet run --project .\samples\SampleConsole\SampleConsole.csproj -c Release -- predict $ModelPath @Inputs
